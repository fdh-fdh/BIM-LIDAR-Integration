# Update-model-fron-Point-Cloud-to-IFC
-This repository give you the first avalibility to update the BIM model from previous Point cloud preception using "Clustering".  
-Here is the repo [Clustering](https://github.com/RicoGoOne/Negative_diff/tree/main/Clustering) again.


## Functions Explanation

### 1. `Opening_Update(ifc, containingwall, voiding)`

- **Description:** This function is part of the `Toolbox.py` module and is used for updating openings within an IFC (Industry Foundation Classes) model by associating them with the appropriate containing wall and voiding elements.

- **Parameters:**
  - `ifc`: The IFC model to be updated.
  - `containingwall`: The wall element that contains the opening.
  - `voiding`: The voiding element representing the opening.

- **Usage:**
  ```python
  Opening_Update(ifc, containingwall, voiding)
- **Example:**:
  ```python
  voiding= voidingFromPointCloud(Pos_x,Pos_y,Pos_z,size_x,size_y,size_z)
  model = ifcopenshell.open(ifc_path)
  Opening_update(model,voiding)

### 2. `Toolbox.find_containing_wall(model, voiding)`
- **Description:** This function is part of the Toolbox.py module and is designed to find the containing wall for a given voiding element within a model.
- **Parameters:**
model: The IFC model to search within.
voiding: The voiding element for which to find the containing wall.
Returns: The containing wall element if found, or None if not found.
- **Usage:**:
  ```python
  containing_wall = Toolbox.find_containing_wall(model, voiding)
- **Example:**:
  ```python
  ifc_file = ifcopenshell.open("your_existing_file.ifc")
  opening = ifc_file.by_type("IfcOpeningElement")[0]
  containing_wall = Toolbox.find_containing_wall(ifc_file, opening)
  if containing_wall:
      print(f"Containing Wall: {containing_wall.Name}")
  else:
      print("Containing Wall not found.")

### 3. `differenciator(clipper, clippee)`
- **Description:** This function performs a geometric operation to calculate the difference between two shapes using the Clipper library.
- **Parameters:**
    clipper: The shape to be used as the clipping shape.
    clippee: The shape to be clipped.
    Returns: The resulting shape after the difference operation.
- **Usage:**:
  ```python
  result_shape = differenciator(clipper, clippee)

- **Example:**
  ```python
  clipper_shape = ...  # read  clipping stl
  clippee_shape = ...  # read the stl  to be clipped
  result_shape = differenciator(clipper_shape, clippee_shape)

- **PS:**
some other funtions in the Toolbox.py are being advised from [IfcOpenshellAcadamy](https://academy.ifcopenshell.org/posts/creating-a-simple-wall-with-property-set-and-quantity-information/)



